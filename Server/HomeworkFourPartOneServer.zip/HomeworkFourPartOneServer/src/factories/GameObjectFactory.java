package factories;

import java.awt.Image;
import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import objectModel.ObjectMap;
import objectModel.Property;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import exceptions.NonUniqueGUIDException;
import exceptions.NullArgumentException;
import actionModel.Action;
import processing.core.PImage;
import processing.core.PVector;
import synchronization.ObjectSynchronizationManager;

/**
 * 
 * 
 * This code was developed with the help and uses some code directly or
 * indirectly found in the tutorial on parsing xml found
 * here:http://www.java-samples.com/showtutorial.php?tutorialid=152
 * 
 * @author James Woods
 * 
 */
public class GameObjectFactory {

	private ObjectSynchronizationManager guids;
	private Random rand;
	private int count;
	private static GameObjectFactory factory;

	private GameObjectFactory() {
		guids = ObjectSynchronizationManager.getManager();
		rand = new Random(System.currentTimeMillis());
	}
	
	public static GameObjectFactory getFactory() {
		if(factory == null)
			factory = new GameObjectFactory();
		return factory;
	}

	public ObjectMap makeObjects(String filePath) {

		// Build the return value.
		ObjectMap toReturn = new ObjectMap();

		// Make a dom object to store parsing data.
		Document dom = null;

		// From tutorial on xml parsing using dom found
		// Here: http://www.java-samples.com/showtutorial.php?tutorialid=152
		// The code found in this tutorial has been modified to suit my needs.

		// get the factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parse using builder to get DOM representation of the XML file
			dom = db.parse(filePath);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		try {
			buildMap(toReturn,  dom);
		} catch (NonUniqueGUIDException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Add the list of GUIDS to the ObjectMap.
		toReturn.GUIDS = guids;

		return toReturn;
	}

	private void buildMap(ObjectMap toReturn, Document dom)
			throws NonUniqueGUIDException {
		// get the root element
		Element docEle = dom.getDocumentElement();

		// get a nodelist of elements. We will be getting elements
		NodeList nl = docEle.getElementsByTagName("GameObject");

		if (nl != null && nl.getLength() > 0) {

			for (int i = 0; i < nl.getLength(); i++) {

				// get the game object element
				Element gameObject = (Element) nl.item(i);

				// Generate the GUID for the object.
				String GUID = gameObject.getAttribute("GUID");

				// If we already have this GUID we must throw an exception.
				if (guids.contains(GUID))
					throw new NonUniqueGUIDException(GUID);
				else
					guids.addObject(GUID);

				// Add the game object properties to the ObjectMap
				addToMap(toReturn, gameObject, GUID);
			}
		}
	}

	private void addToMap(ObjectMap toReturn, Element gameObject, String GUID) {
		// Get the node list for the properties.
		NodeList nl = gameObject.getElementsByTagName("Property");

		if (nl != null && nl.getLength() > 0) {

			for (int i = 0; i < nl.getLength(); i++) {

				// get the property element
				Element property = (Element) nl.item(i);

				// get the type value for the property.
				String type = property.getAttribute("type");

				// If the property exists in the map just add parameters to the
				// property.
				if (toReturn.contains(type)) {
					try {
						Property toBeCompleted = toReturn.get(type);
						completeProperty(toBeCompleted, property, GUID);
					} catch (NullArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				// otherwise create a new property and add it to the map.
				else {
					// Add the property to the ObjectMap
					try {
						toReturn.add(type, getProperty(property, type, GUID));
					} catch (NullArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}

	}

	private void completeProperty(Property toBeCompleted, Element property,
			String GUID) {

		// Get the node list for the parameters.
		NodeList nl = property.getElementsByTagName("Parameter");

		if (nl != null && nl.getLength() > 0) {

			// Build the ordered parameter list.
			Object[] toAdd = new Object[nl.getLength()];

			for (int i = 0; i < nl.getLength(); i++) {

				// get the parameter element
				Element parameter = (Element) nl.item(i);

				// Add the parameter to the parameter list.
				toAdd[i] = getParameterValue(parameter);

			}

			// Add the list of parameters to the Property.
			toBeCompleted.addNewParameterList(GUID, toAdd);
		}

	}

	private Object getParameterValue(Element parameter) {

		// get the type value for the parameter.
		String type = parameter.getAttribute("type");

		// Now determine the correct type for the parameter and parse the
		// parameter accordingly. NOTE: This is where we can add new data types
		// to
		// the game when needed.
		if ("float".equals(type.toLowerCase()))
			return parseFloatValue(parameter);
		else if ("pvector".equals(type.toLowerCase()))
			return parsePVectorValue(parameter);
		else if ("text".equals(type.toLowerCase()))
			return getTextValue(parameter);
		else if ("bool".equals(type.toLowerCase()))
			return parseBooleanValue(parameter);
		else if ("image".equals(type.toLowerCase()))
			return getTextValue(parameter);
		else if ("rectangle".equals(type.toLowerCase()))
			return parseRectangleValue(parameter);
		else if ("polygon".equals(type.toLowerCase()))
			return parsePolygonValue(parameter);
		else if ("int".equals(type.toLowerCase()))
			return parseIntValue(parameter);
		else if ("randomint".equals(type.toLowerCase()))
			return getRandomInt(parameter);

		return null;
	}

	private Object getRandomInt(Element parameter) {
		int max = (int) parseIntValue(parameter);
		return rand.nextInt(max + 1);
	}

	private Object parseIntValue(Element parameter) {
		return  Integer.parseInt(getTextValue(parameter));
	}

	private Object parsePolygonValue(Element parameter) {

		return null;
	}

	private Object parseRectangleValue(Element parameter) {
		String values[] = getTextValue(parameter).split(", ");

		return new Rectangle(Integer.parseInt(values[0]),
				Integer.parseInt(values[1]));
	}

	private Object parseFloatValue(Element parameter) {
		return Float.parseFloat(getTextValue(parameter));
	}

	private Object parseBooleanValue(Element parameter) {
		return Boolean.parseBoolean(getTextValue(parameter));
	}

	private String getTextValue(Element parameter) {

		return parameter.getFirstChild().getNodeValue();
	}

	private Object parsePVectorValue(Element parameter) {

		String values[] = getTextValue(parameter).split(",");

		return new PVector(Float.parseFloat(values[0]),
				Float.parseFloat(values[1]), 0);
	}

	private Property getProperty(Element property, String type, String GUID) {

		Property toReturn = new Property(type);

		completeProperty(toReturn, property, GUID);

		return toReturn;
	}

	/**
	 * Generates a sequential guid for new players.
	 * @return the newly made guid for a new player.
	 */
	public String getGUID() {
		String guid = "newplayer" + count++;
		while(guids.contains(guid)) {
			guid = "newplayer" + count++;
		}
		return guid;
	}

	/**
	 * builds a character with the given GUID.
	 * @param gUID
	 * @return the new player character in an object map.
	 */
	public ObjectMap buildCharacter(String gUID, String characterName, String filePath) {
		// Build the return value.
		ObjectMap toReturn = new ObjectMap();

		// Make a dom object to store parsing data.
		Document dom = null;

		// From tutorial on xml parsing using dom found
		// Here: http://www.java-samples.com/showtutorial.php?tutorialid=152
		// The code found in this tutorial has been modified to suit my needs.

		// get the factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parse using builder to get DOM representation of the XML file
			dom = db.parse(filePath);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		buildObject(toReturn,  dom, characterName, gUID);
		
		return toReturn;
	}

	private void buildObject(ObjectMap toReturn, Document dom, String characterName, String gUID) {
		
		// get the root element
		Element docEle = dom.getDocumentElement();

		// get a nodelist of elements. We will be getting elements
		NodeList nl = docEle.getElementsByTagName("GameObject");

		if (nl != null && nl.getLength() > 0) {

			for (int i = 0; i < nl.getLength(); i++) {

				// get the game object element
				Element gameObject = (Element) nl.item(i);

				// Generate the GUID for the object.
				String GUID = gameObject.getAttribute("GUID");
				
				if(GUID.equals(characterName)) {
					
					GUID = gUID;
				
					guids.addObject(GUID);

					// Add the game object properties to the ObjectMap
					addToMap(toReturn, gameObject, GUID);
					break;
				}
			}
		}
	}
}
