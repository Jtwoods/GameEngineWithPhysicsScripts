package server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentLinkedQueue;

import synchronization.ObjectSynchronizationManager;
import time.TimeManager;
import eventModel.Event;
import eventModel.EventHandler;
import homeworkFourPartOneServer.HomeworkFourPartOneServer;

/**
 * This is really just a monitor that constantly checks that the client
 * connections are maintained and removes them from the game if they disconnect.
 * 
 * @author James Woods
 * 
 */
public class ClientResourcesServlet implements Runnable {

	private SharedSpace shared;
	private TimeManager tManager;

	// This is the list of sockets connected to the server.
	public ConcurrentLinkedQueue<ClientConnection> clients;

	public ClientResourcesServlet(SharedSpace shared) {
		this.shared = shared;
		tManager = TimeManager.getManager();
		clients = new ConcurrentLinkedQueue<ClientConnection>();
	}

	@Override
	public void run() {

		// Create a list to store dead connections.
		ArrayList<ClientConnection> toRemove = new ArrayList<ClientConnection>();

		for (ClientConnection connection : clients) {
			if (connection.client.isClosed()
					|| !connection.client.isConnected()
					|| !connection.client.isBound()) {

				// We will make sure that the connections are closed.
				// This will throw an Exception if they are already closed.
				try {
					connection.in.close();
					connection.out.close();
					toRemove.add(connection);
				} catch (IOException e1) {
				}

				// Add them to the remove list.
				toRemove.add(connection);
			} else {
				// Otherwise we will get the event queue from the client.
				try {
					@SuppressWarnings("unchecked")
					PriorityQueue<Event> toAdd = (PriorityQueue<Event>) connection.in
							.readObject();

					shared.addEvents(toAdd);
					
					tManager.addAllEvents(toAdd);

					// Then send the game objects to the client.
					Object[] toSend = new Object[3];
					toSend[0] = shared.getObjects();
					toSend[1] = tManager.getCurrentStepEvents();
					toSend[2] = ObjectSynchronizationManager.getManager();
					connection.out.writeObject(toSend);
					

					// Reset the object stream out here.
					connection.out.reset();

				} catch (ClassNotFoundException | IOException e) {
					// We will make sure that the connections are closed.
					// This will throw an Exception if they are already closed.
					try {
						connection.in.close();
						connection.out.close();
						toRemove.add(connection);
					} catch (IOException e1) {
					}

					// Add them to the remove list.
					toRemove.add(connection);
				}

			}
		}

		// Remove all closed connections.
		for (ClientConnection connection : toRemove) {
			// Remove the client character from the game objects.
			shared.remove(connection.GUID);

			// Remove the connection thread from the list of threads.
			clients.remove(connection);
		}

	}

	/**
	 * Adds the newly received client to the list of connections and then adds a
	 * new character object to the game objects.
	 * 
	 * @param connection
	 *            the connection to add.
	 */
	public void add(ClientConnection connection) {
		// Add the client connection.
		clients.add(connection);

		// Add the new player object.
		shared.addPlayer(connection.GUID);
	}

}
