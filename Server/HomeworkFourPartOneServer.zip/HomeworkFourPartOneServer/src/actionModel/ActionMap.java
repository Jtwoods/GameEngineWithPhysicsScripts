package actionModel;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * ActionMap stores loaded Action classes of different types.
 * These Action classes can be loaded at runtime and used
 * to perform scripted actions.
 * 
 * Each action will be stored as a list by a type parameter
 * so that a list of a certain type can be requested and processed
 * when needed.
 * 
 * @author James Woods
 *
 */
public class ActionMap {
	
	private HashMap<String, ArrayList<Action>> actions;
	
	public ActionMap() {
		actions = new HashMap<String, ArrayList<Action>>();
	}

	/**
	 * returns true if the ActionMap contains the given type
	 * of Action. Remember, type is the category of Action. Example: Physics or AI
	 * @param type
	 * @return
	 */
	public boolean contains(String type) {
		return actions.containsKey(type);
	}

	/**
	 * returns the list of Actions of the given type.
	 * @param type the type of the action. Example: AI
	 * @return the list of actions of the given type.
	 */
	public ArrayList<Action> get(String type) {
		return actions.get(type);
	}

	/**
	 * Adds the action of the given type to the map.
	 * If the type does not already exist in the map
	 * it will be created and the action will be added
	 * to the new type category.
	 * @param type the type of the action. Example: Physics
	 * @param action the Action to be added.
	 */
	public void add(String type, Action action) {
		//Get the ArrayList of the type to be added.
		ArrayList<Action> toUpdate = actions.get(type);
		
		//If this is null create a new list for the type and add it.
		if(toUpdate == null) {
			toUpdate = new ArrayList<Action>();
			actions.put(type, toUpdate);
		}
		
		//Add the action to the list.
		toUpdate.add(action);
	}

	
}
