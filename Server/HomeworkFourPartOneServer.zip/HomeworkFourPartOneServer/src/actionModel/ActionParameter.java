package actionModel;

import java.util.ArrayList;

public class ActionParameter {

	public String[] parameterList;
	public String class_name;
	public String GUID;
	public ArrayList<Object[]> properties; 
	public double time;
	
	public ActionParameter() {
		properties = new ArrayList<Object[]>();
	}

}
