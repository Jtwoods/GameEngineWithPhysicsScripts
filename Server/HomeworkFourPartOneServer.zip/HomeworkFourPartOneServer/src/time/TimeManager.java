package time;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.PriorityQueue;

import eventModel.Event;
import objectModel.ObjectMap;

public class TimeManager implements Serializable {

	private static final int TIME_DEVISOR = 1000000;
	private static final int WINDOW_SIZE = 8;

	private static TimeManager manager;
	private TimeLine global_timeline;
	private TimeStep current;
	private int step;
	private boolean setObjects;

	// These parameters track the time step between frames.
	private double time;
	private double actual;
	private double prevActual;
	private double[] prevTimes;
	private double prevUsed;
	private int count;

	private TimeManager() {
		global_timeline = new TimeLine();
		current = new TimeStep();
		setObjects = true;
		step = 0;

		// Initialize the time keeping for the game loop.
		// We will use a stable time stamp so that if the game
		// loop lags the animation will slow down.
		// This prevents the time stamp from growing
		// too large if the game loop lags, which will
		// cause objects to reach crazy velocities.
		// That said, we will try to keep lag down.
		time = 0;
		prevActual = Math.abs(System.nanoTime()) / TIME_DEVISOR;
		actual = 0;
		prevTimes = new double[WINDOW_SIZE];
		prevUsed = 0;

		// Initialize the count.
		count = 0;
	}

	public static TimeManager getManager() {
		if (manager == null)
			manager = new TimeManager();
		return manager;
	}

	/**
	 * returns a small slice of the global time line from the given start to the
	 * given finish.
	 * 
	 * @param start
	 *            the step to start the time line at.
	 * @param finish
	 *            the step to end the time line at.
	 * @param tic_size
	 * @return
	 */
	public TimeLine getTimeLine(int start, int finish, double tic_size) {
		
		ObjectMap map = global_timeline.getStep(start).initial;
		
		TimeLine toBuild = global_timeline.slice(start, finish);
		
		toBuild = build(toBuild, tic_size);
		toBuild.getStep(0).initial = map;

		return toBuild;
	}

	private TimeLine build(TimeLine toBuild, double tic_size) {
		ArrayList<TimeStep> adjusted = new ArrayList<TimeStep>();
		ArrayList<TimeStep> line = (ArrayList<TimeStep>) toBuild.steps.clone();
		if(Math.abs(tic_size - 1) <= .1)
			return toBuild;
		if (line.size() > 0) {

			TimeStep toCheck = line.remove(0);
			double adjusted_time = toCheck.elapsed_time / tic_size;
			double elapsed_time = 0;
			PriorityQueue<Event> oneSlice = new PriorityQueue<Event>();

			while (toCheck != null) {
				if (adjusted_time > toCheck.elapsed_time + elapsed_time) {
					Event event = getNextEvent(toCheck);
					while (event != null) {
						event.time_stamp += elapsed_time;
						oneSlice.add(event);
						event = getNextEvent(toCheck);
					}

					elapsed_time += toCheck.elapsed_time;

					if (line.size() > 0) {
						toCheck = line.remove(0);
						adjusted_time = toCheck.elapsed_time / tic_size;
					} else
						toCheck = null;

				} else {
					double event_time = 0;
					Event event = getNextEvent(toCheck);
					if (event != null) {
						event_time = event.time_stamp;
						while (event != null
								&& adjusted_time > event_time + elapsed_time) {
							event.time_stamp += elapsed_time;
							oneSlice.add(event);
							event = getNextEvent(toCheck);
							if (event != null)
								event_time = event.time_stamp;
						}
					} else if (tic_size > 1) {
						if (line.size() > 0) {
							toCheck = line.remove(0);
							adjusted_time = toCheck.elapsed_time / tic_size;
							elapsed_time = 0;
						} else
							toCheck = null;
					}
					elapsed_time += event_time;
					TimeStep toAdd = new TimeStep();
					toAdd.elapsed_time = adjusted_time;
					if (event != null) {
						event.time_stamp += elapsed_time;
						oneSlice.add(event);
					}
					toAdd.events = oneSlice;
					adjusted.add(toAdd);
					oneSlice = new PriorityQueue<Event>();

					if (tic_size < 1) {
						if (line.size() > 0) {
							toCheck = line.remove(0);
							adjusted_time = toCheck.elapsed_time / tic_size;
							elapsed_time = 0;
						} else
							toCheck = null;
					}
				}

			}
		}

		toBuild.steps = adjusted;
		return toBuild;
	}

	private Event getNextEvent(TimeStep toCheck) {
		Event event = toCheck.events.poll();
		 if (event == null)
		 return event;
		 if (event.getType() == "KeyPressed".hashCode()
		 || event.getType() == "KeyReleased".hashCode()
		 || event.getType() == "SpawnNew".hashCode())
		 return event;
		 else {
		 event = getFilteredEvent(toCheck, event);
		 }
		return event;
	}

	private Event getFilteredEvent(TimeStep toCheck, Event event) {
//		while (event != null
//				&& (event.getType() != "KeyPressed".hashCode()
//						&& event.getType() != "KeyReleased".hashCode() && event
//						.getType() != "SpawnNew".hashCode()))
//			event = toCheck.events.poll();
		return event;
	}

	private boolean filter(Event event) {
		if (event != null)
			return (event.getType() != "KeyPressed".hashCode()
					&& event.getType() != "KeyReleased".hashCode() && event
						.getType() != "SpawnNew".hashCode());
		return false;
	}

	/**
	 * returns the current elapsed time in the time step.
	 * 
	 * @return the current elapsed time in the time step in milliseconds.
	 */
	public double currentTimeInStep() {
		return Math.abs(System.nanoTime()) / TIME_DEVISOR - actual;
	}

	/**
	 * provides time smoothing.
	 */
	public void startFrame() {
		// USING HIGH RESOLUTION TIMER.
		actual = Math.abs(System.nanoTime()) / TIME_DEVISOR;

		prevUsed = (actual - prevActual);

		if (step == 0) {
			time = prevUsed;
			prevTimes[(int) step] = prevUsed;
		} else if ((int) step >= WINDOW_SIZE) {
			double sum = prevUsed;
			int size = prevTimes.length;

			for (int i = 0; i < size - 1; i++) {
				sum += prevTimes[i];
				prevTimes[i] = prevTimes[i + 1];
			}
			prevTimes[size - 1] = prevUsed;

			time = sum / size;

		} else {
			double sum = prevUsed;

			for (int i = 0; i < (int) step; i++) {
				sum += prevTimes[i];
			}

			prevTimes[(int) step] = prevUsed;

			time = sum / ((int) step + 1);
		}

	}

	/**
	 * returns the current count for this manager.
	 * 
	 * @return
	 */
	public int getCount() {
		return count;
	}

	/**
	 * resets the count for this time manager.
	 */
	public void resetCount() {
		count = 0;
	}

	/**
	 * performs update to the time as needed at the end of a frame.
	 */
	public void endFrame(ObjectMap displayed) {
		// Build the TimeStep and add it to the TimeLine.
		if (setObjects) {
			current.initial = displayed;
			setObjects = false;
		}

		current.elapsed_time = time;

		global_timeline.addStep(current);

		// Create the next step.
		current = new TimeStep();

		// Save the actual time.
		prevActual = actual;

		// Increase the frame count.
		count++;

		// Increment the step.
		step++;
	}

	/**
	 * returns the elapsed time for this frame.
	 * 
	 * @return
	 */
	public double frameTime() {
		return time;
	}

	/**
	 * Returns the current step number and flags the Manager to record the
	 * ObjectModel for this step.
	 * 
	 * @return the step number.
	 */
	public int setStart() {
		setObjects = true;
		return step;
	}

	/**
	 * Saves the given event queue in the TimeStep for this time step.
	 * 
	 * @param toStore
	 */
	public void setStepEvents(PriorityQueue<Event> toStore) {
		current.events = toStore;
	}

	public int getStep() {
		return step;
	}

	public double getAvgStepDurration() {
		return time;
	}

	public PriorityQueue<Event> getCurrentStepEvents() {
		return current.events;
	}

	public void addAllEvents(PriorityQueue<Event> object) {
		current.events = object;
	}
}
