package operations;

import actionModel.ActionMap;
import actionPerformer.ActionPerformer;
import objectModel.ObjectMap;

public class PhysOperation implements Runnable {

	private ActionMap actions;
	private ObjectMap objects;
	private double time;
	public ActionPerformer physics;

	public PhysOperation(ActionMap actions, ObjectMap objects, double time2) {
		this.actions = actions;
		this.objects = objects;
		this.time = time2;
		this.physics = new ActionPerformer("Physics");
	}

	@Override
	public void run() {
		physics.run(actions, objects, time);
	}

}
