package synchronization;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Is a manager that provides several custom iterators that provide for the
 * synchronized access of GameObjects. Each iterator provides an iterable list
 * of GUID, Lock pairs that can be used to lock on a GUID, thus ensuring that
 * each object is only modified by one thread at a time.
 * 
 * NOTE: The ReQueueableIterator returned by the getIterator method requires
 * that the hasNext() method is used. The hasNext() method unlocks the
 * previously returned GUID. Also, the unlock method is provided to allow the
 * caller to create a try between the next() and hasNext() calls with a finally
 * block that calls the unlock(). This will prevent a GUID from being
 * permanently locked in the event that an exception is thrown during the
 * callers operations on the GUID.
 * 
 * @author James Woods
 * 
 */
public class ObjectSynchronizationManager implements Serializable {

	private HashMap<String, ReentrantLock> list;
	private static ObjectSynchronizationManager manager;
	private int count;

	private ObjectSynchronizationManager() {
		count = 0;
		list = new HashMap<String, ReentrantLock>();
	}

	/**
	 * returns the one and only instance of this manager.
	 * 
	 * @param caller
	 *            the name of the calling object.
	 * @return the
	 */
	public synchronized static ObjectSynchronizationManager getManager() {
		if (manager == null)
			manager = new ObjectSynchronizationManager();
		return manager;
	}

	/**
	 * Adds the GUID to the list of GUIDS.
	 * 
	 * @param guid
	 *            the GUID to add.
	 */
	public void addObject(String guid) {
		synchronized (this) {
			list.put(guid, new ReentrantLock());
		}
	}

	/**
	 * provides the caller with a ReQueueableIterator that will maximize the
	 * speed of iteration and allow the GUID references to be accessed under
	 * synchronization. That is, the given GUID will be locked on inside the
	 * iterator. This means that any other concurrent callers to the iterator
	 * will not be given the locked GUID until it is available.
	 * 
	 * @return ReQueueableIterator
	 */
	public ReQueueableIterator getIterator(int caller) {

		ReQueueableIterator toReturn = null;
		synchronized (this) {
			if (caller == 1) {
				toReturn = new ForwardIterator();
			}
			else {
				toReturn = new BackwardIterator();
			}
			count++;
		}
		return toReturn;
	}

	public Iterable<String> getUnlockedIterator() {
		return list.keySet();
	}

	public boolean contains(String GUID) {
		return list.containsKey(GUID);
	}

	private class ForwardIterator implements ReQueueableIterator {

		private Queue<String> guids;
		private Queue<String> toDo;
		private Lock current;

		public ForwardIterator() {
			guids = new LinkedList<String>();
			toDo = new LinkedList<String>();
			guids.addAll(list.keySet());
			current = null;
		}

		@Override
		public boolean hasNext() {
			return guids.size() > 0 || toDo.size() > 0;
		}

		@Override
		public String next() {

			// Get the next guid to return.
			String guid = null;
			
			if (guids.size() > 0)
				guid = guids.remove();
			else if (toDo.size() > 0)
				guid = toDo.remove();
			else
				return null;

			if(guid == null)
				return null;
			
			// Now get the lock for this GUID.
			Lock toCheck = list.get(guid);

			// Until we find a GUID that is available
			// Add the GUID to the toDo list and
			// keep looking.
			while (!toCheck.tryLock()) {

					toDo.add(guid);

				if (guids.size() > 0)
					guid = guids.remove();
				else if (toDo.size() > 0) {
					guid = toDo.remove();
				}
				else
					return null;

				// Now get the lock for this GUID.
				toCheck = list.get(guid);
				if (toCheck == null)
					return null;
			}
			
			current = toCheck;

			return guid;
		}

		@Override
		public void unLock() {
			if (current != null)
				current.unlock();
			current = null;
		}

	}

	private class BackwardIterator implements ReQueueableIterator {

		private ArrayList<String> guids;
		private Queue<String> toDo;
		private Lock current;

		public BackwardIterator() {
			guids = new ArrayList<String>();
			toDo = new LinkedList<String>();
			guids.addAll(list.keySet());
			current = null;
		}

		@Override
		public boolean hasNext() {
			return !guids.isEmpty() || !toDo.isEmpty();
		}

		@Override
		public String next() {

			// Get the next guid to return.
			String guid = null;

				if (guids.size() > 0)
					guid = guids.remove(guids.size() - 1);
				else if (toDo.size() > 0)
					guid = toDo.remove();
				else
					return null;

			// Now get the lock for this GUID.
			Lock toCheck = list.get(guid);

			// Until we find a GUID that is available
			// Add the GUID to the toDo list and
			// keep looking.
			while (!toCheck.tryLock()) {

					toDo.add(guid);

					if (guids.size() > 0)
						guid = guids.remove(guids.size() - 1);
					else if (toDo.size() > 0) {
						guid = toDo.remove();
					}
					else
						return null;


				// Now get the lock for this GUID.
				toCheck = list.get(guid);
				if (toCheck == null)
					return null;
			}

			current = toCheck;

			return guid;
		}

		@Override
		public void unLock() {
			if (current != null)
				current.unlock();
			current = null;
		}

	}

	public Lock getLock(String guid) {
		return list.get(guid);
	}

	public Iterable<String> getUnlockedForwardIteratorAfter(String gUID) {
		ArrayList<String> toSub = new ArrayList<String>();
		toSub.addAll(list.keySet());
		List<String> toReturn = toSub.subList(toSub.indexOf(gUID), toSub.size());
		return toReturn;
	}
	
	public void setManager(ObjectSynchronizationManager manager) {
		this.manager = manager;
	}

}
