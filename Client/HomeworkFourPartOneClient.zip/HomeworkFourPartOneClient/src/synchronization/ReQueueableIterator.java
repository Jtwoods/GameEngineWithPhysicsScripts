package synchronization;

import java.util.Iterator;

/**
 * This is a special Iterator 
 * that is provided by the ObjectSynchronizationManager.
 * This iterator allows objects to be added back into the
 * iterator, re-queued, and returned again later.
 * @author James Woods
 *
 */
public interface ReQueueableIterator {

	public boolean hasNext();


	public String next();
	
	
	public void unLock();

}
