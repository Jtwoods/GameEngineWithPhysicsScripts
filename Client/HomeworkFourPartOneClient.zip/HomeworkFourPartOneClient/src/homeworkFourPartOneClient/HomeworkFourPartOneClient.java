package homeworkFourPartOneClient;

import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.PriorityQueue;

import objectModel.ObjectMap;
import objectModel.Property;
import eventModel.Event;
import eventModel.EventManager;
import eventModel.EventMap;
import eventModel.EventParameter;
import eventModel.ObjectParameter;
import exceptions.NullArgumentException;
import factories.EventFactory;
import processing.core.PApplet;
import processing.core.PImage;
import synchronization.ObjectSynchronizationManager;
import time.PlayBackManager;
import time.TimeManager;

public class HomeworkFourPartOneClient extends PApplet {

	private TimeManager tManager;
	public ObjectMap objects;
	private EventMap events;
	private EventManager eManager;
	private PlayBackManager pManager;
	private Thread mock;

	private HashMap<String, PImage> images;

	// This will store the GUID for this player.
	private String playerGUID = "SomethingMoving";

	// input and output to the server.
	public ObjectInputStream in;
	public ObjectOutputStream out;

	// Server
	public static String server;
	public static int port;
	public Socket client;

	public void setup() {

		mock = null;
		
		// Instantiate the hash map of images
		// that will be used to store loaded images.
		images = new HashMap<String, PImage>();

		// Build the EventMap.
		EventFactory eFactory = new EventFactory();
		events = eFactory.makeEvents("events.xml");

		// Get the singleton EventManager.
		eManager = EventManager.getManager();
		// Set the event map.
		eManager.setEventMap(events);

		// Set the size of the display and the frame rate.
		size(1000, 600);
		frameRate(60);

		try {
			// Establish a connection to the server.
			client = new Socket(server, port);

			// Get the input and output streams set up.
			out = new ObjectOutputStream(client.getOutputStream());
			in = new ObjectInputStream(client.getInputStream());

			// We must get the GUID for the player object and TimeManager from
			// the server.
			Object[] toUse = (Object[]) in.readObject();
			playerGUID = (String) toUse[0];
			tManager = (TimeManager) toUse[1];

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		pManager = PlayBackManager.getManager();
		pManager.setTimeManager(tManager);
	}

	public void keyPressed() {

		if (key == 'r' || key == 'R') {
			PlayBackManager pManager = PlayBackManager.getManager();
			pManager.setStart();
		}
		if (key == 'f' || key == 'F') {
			PlayBackManager pManager = PlayBackManager.getManager();
			pManager.startPlayBack(0.5);
		}
		if (key == 's' || key == 'S') {
			PlayBackManager pManager = PlayBackManager.getManager();
			pManager.startPlayBack(2.0);
		}
		if (key == 'n' || key == 'N') {
				PlayBackManager pManager = PlayBackManager.getManager();
				pManager.startPlayBack(1.0);
		}
		
		// Build an event parameter with
		// The key press as additional information.
		EventParameter param = new EventParameter();
		param.additional = new Object[2];
		param.additional[0] = keyCode;
		param.additional[1] = key;

		ObjectParameter obj = new ObjectParameter();
		obj.parameterList = new String[5];
		obj.parameterList[0] = "Velocity";
		obj.parameterList[1] = "Acceleration";
		obj.parameterList[2] = "OnTop";
		obj.parameterList[3] = "MAX_ACCEL";
		obj.parameterList[4] = "JUMP_VEL";

		obj.GUID = playerGUID;

		param.objectParameters.add(obj);

		// Now build the event and add it to the EventManager queue.
		eManager.addEvent(new Event("KeyPressed", param));

	}

	public void keyReleased() {

		// Build an event parameter with
		// The key press as additional information.
		EventParameter param = new EventParameter();
		param.additional = new Object[1];
		param.additional[0] = keyCode;

		ObjectParameter obj = new ObjectParameter();
		obj.parameterList = new String[1];
		obj.parameterList[0] = "Acceleration";

		obj.GUID = playerGUID;

		param.objectParameters.add(obj);

		// Now build the event and add it to the EventManager queue.
		eManager.addEvent(new Event("KeyReleased", param));

	}

	public void draw() {

		tManager.startFrame();

		ObjectMap toDraw = null;

		objects = null;

		if (!pManager.playing) {
			if(mock != null) {
				//Play back has just ended.
				try {
					mock.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mock = null;
				//Reset the playback manager.
				pManager.reset();
			}
				
			// Build the Object to send to the server.
			PriorityQueue<Event> toSend = eManager.purgeQueue();

			try {
				// Send the data to the server.
				out.writeObject(toSend);
				out.reset();

				// Receive the updated object information from the
				// Server.
				Object[] toUse = (Object[]) in.readObject();

				objects = (ObjectMap) toUse[0];

				tManager.addAllEvents((PriorityQueue<Event>) toUse[1]);
				ObjectSynchronizationManager sync = ObjectSynchronizationManager
						.getManager();
				sync.setManager((ObjectSynchronizationManager) toUse[2]);
				toDraw = objects;

			} catch (IOException e) {
				e.printStackTrace();
				try {
					in.close();
					out.close();
					exit();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			//The play back is running.
			if(mock == null) {
				mock = new Thread(new MockClient());
				mock.start();
			}
			toDraw = pManager.takeStep();
			objects = toDraw;
		}
		// Start rendering.

		// Clear the screen and draw the background.
		clear();
		background(204);

		// Rendering will be hard coded to allow use of the
		// PApplet. Animation can be scripted by updating the
		// Representation property with event handlers or general scripts.
		try {

			Property positions = toDraw.get("Position");
			Property representation = toDraw.get("Representation");
			Property bounds = toDraw.get("BoundingBox");
			Property colors = toDraw.get("Color");

			for (String guid : toDraw.GUIDS.getUnlockedIterator()) {
				Object[] pos = positions.getParameters(guid);
				Object[] string = representation.getParameters(guid);
				Object[] rect = bounds.getParameters(guid);
				Object[] hue = colors.getParameters(guid);

				if (pos != null) {

					float Xpos = (float) pos[0];
					float Ypos = (float) pos[1];

					Rectangle box = null;

					if (rect != null)
						box = (Rectangle) rect[0];

					int color[] = new int[3];
					color[0] = 0;
					color[1] = 0;
					color[2] = 255;

					if (hue != null) {
						color[0] = (int) hue[0];
						color[1] = (int) hue[1];
						color[2] = (int) hue[2];
					}

					PImage image = null;

					// We will memoize the images as they are loaded the
					// first time.
					if (string != null) {
						if (images.containsKey((String) string[0])) {
							image = images.get((String) string[0]);
						} else {
							image = loadImage((String) string[0]);
							images.put((String) string[0], image);
						}
					}

					pushMatrix();
					if (image != null && box != null) {
						fill(color[0], color[1], color[2]);
						ellipse(Xpos, Ypos, box.height, box.width);
						image(image, (float) (Xpos - box.width * .5f),
								(float) (Ypos - box.height * .5f));
					} else if (box != null) {
						fill(color[0], color[1], color[2]);
						rect(Xpos - box.width * .5f, Ypos - box.height * .5f,
								box.width, box.height);
					}
					popMatrix();

				}

			}

		} catch (NullArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		tManager.endFrame(toDraw);

	}

	private class MockClient implements Runnable {

		@Override
		public void run() {
			while (pManager.playing) {
				try {
					PriorityQueue<Event> toSend = new PriorityQueue<Event>();
					// Send the data to the server.
					out.writeObject(toSend);
					out.reset();

					Object[] toUse = (Object[]) in.readObject();

				} catch (IOException e) {
					e.printStackTrace();
					try {
						in.close();
						out.close();
						exit();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}

	public static void main(String[] args) {
		server = args[0];
		port = Integer.parseInt(args[1]);
		PApplet.main(new String[] { HomeworkFourPartOneClient.class.getName() });
	}

}
