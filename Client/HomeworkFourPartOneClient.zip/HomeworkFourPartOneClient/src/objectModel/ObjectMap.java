package objectModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import synchronization.ObjectSynchronizationManager;
import exceptions.NullArgumentException;

/**
 * ObjectMap contains the list of all properties used by the game.
 * 
 * @author James Woods
 */
public class ObjectMap implements Serializable, Cloneable {

	private HashMap<String, Property> map;

	public ObjectSynchronizationManager GUIDS;

	public ObjectMap() {
		map = new HashMap<String, Property>();
		GUIDS = ObjectSynchronizationManager.getManager();
	}

	public synchronized void add(String property, Property column)
			throws NullArgumentException {
		if (property != null && column != null) {
			map.put(property, column);
		} else {
			if (property == null)
				throw new NullArgumentException("property is null");
			if (column == null)
				throw new NullArgumentException("column is null");
		}
	}

	public synchronized Property get(String property) throws NullArgumentException {
		if (property == null)
			throw new NullArgumentException("property is null");
		Property toReturn = map.get(property);
		return toReturn;
	}

	public boolean contains(String property) {
		return map.containsKey(property);
	}

	public Object keySet() {
		return map.keySet();
	}
	
	public ObjectMap clone() {
		ObjectMap toReturn = new ObjectMap();
		toReturn.GUIDS = this.GUIDS;
		toReturn.map = (HashMap<String, Property>) map.clone();
		
		return toReturn;
	}

	/**
	 * Removes the given object from the game object model.
	 * @param gUID the GUID of the object to remove.
	 */
	public synchronized void remove(String gUID) {
		//Move through the properties in the object model.
		
		for(String key: map.keySet()) {
			//Get the property.
			Property toCheck = map.get(key);
			toCheck.removeGuid(gUID);
		}
	}

	public void addCharacter(ObjectMap buildCharacter, String GUID) {
		Set<String> keys = (Set<String>) buildCharacter.keySet();
		
		for(String key: keys) {
			// If the property exists in the map just add parameters to the
			// property.
			if (map.containsKey(key)) {
				try {
					Property toUpdate = map.get(key);
					Property toAdd = buildCharacter.get(key);
					toUpdate.addNewParameterList(GUID, toAdd.getParameters(GUID));
				} catch (NullArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			// otherwise create a new property and add it to the map.
			else {
				// Add the property to the ObjectMap
				try {
					Property toAdd = buildCharacter.get(key);
					map.put(key, toAdd);
				} catch (NullArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
