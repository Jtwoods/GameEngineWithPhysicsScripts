package objectModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Property implements Serializable, Iterable<Object[]>, Cloneable {

	/**
	 * This is the name associated with this Property.
	 * Example: Velocity
	 */
	private String type;
	
	private HashMap<String, Object[]> properties;
	
	/**
	 * Constructs a Property of the given type with the
	 * given parameter values.
	 * @param type the type of the Property. Example: Velocity.
	 * @param format the ordered type format of the parameters as a String. Example: <int/> <float/> <PVector/>
	 */
	public Property(String type) {
		
		//Instantiate the properties.
		this.properties = new HashMap<String, Object[]>();
		
		//Set the type.
		this.type = type;
	}
	
	/**
	 * returns the type of this Property.
	 * @return type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * returns the Property parameter at the given position if the typeOf argument matches
	 * the parameter type.
	 * @param GUID the Global Unique Identifier for the object.
	 * @param typeOf
	 * @param position
	 * @return 
	 */
	public Object getParameter(String GUID, int position) {
		Object toReturn = ((Object[])properties.get(GUID))[position];
		return toReturn;
	}
	
	public Object[] getParameters(String GUID) {
		return (Object[])properties.get(GUID);
	}
	
	/**
	 * Adds the given element to the parameters given the GUID of the object
	 * to which the parameter belongs and the position in the parameter list. 
	 * @param GUID the guid of the owner of the parameter.
	 * @param position the position in the parameter list.
	 * @param toAdd the element to be added.
	 */
	public void addParameter(String GUID, int position, Object toAdd) {
		((Object[])properties.get(GUID))[position] = toAdd;
	}
	
	/**
	 * Adds the given parameter list to the Property given the 
	 * GUID for the owner of the parameter list.
	 * @param GUID the guid of the owner of the given parameters.
	 * @param toAdd the parameter list to be added.
	 */
	public void addNewParameterList(String GUID, Object[] toAdd) {
		properties.put(GUID, toAdd);
	}
	
	/**
	 * Updates the given parameter list to the Property given the 
	 * GUID for the owner of the parameter list.
	 * @param GUID the guid of the owner of the given parameters.
	 * @param toAdd the parameter list to be added.
	 */
	public void updateParameterList(String GUID, Object[] toAdd) {
		properties.put(GUID, toAdd);
	}

	@Override
	public Iterator<Object[]> iterator() {
		return new MapIterate();
	}
	
	public Property clone() {
		Property toReturn = new Property(type);
		toReturn.properties = (HashMap<String, Object[]>) properties.clone();
		
		return toReturn;
	}
	
	private class MapIterate implements Iterator<Object[]> {
		
		private Iterator<String> iterate;
		private String current;
		
		public MapIterate() {
			Set<String> indices = properties.keySet();
			iterate = indices.iterator();
			current = null;
		}
		
		@Override
		public boolean hasNext() {
			return iterate.hasNext();
		}

		@Override
		public Object[] next() {
			current = (String) iterate.next();
			return properties.get(current);
		}

		@Override
		public void remove() {
			if(current != null) {
				properties.remove(current);
				iterate.remove();
			}
		}
		
	}

	/**
	 * returns a randomly chosen GUID from the list 
	 * of objects that have this Property.
	 * @return the GUID or null if there are none.
	 */
	public String getRandomGUID() {
		String toReturn = null;
		Random rand = new Random(System.currentTimeMillis());
		
		Set<String> keys = properties.keySet();
		ArrayList<String> arrayOfKeys = new ArrayList<String>();
		arrayOfKeys.addAll(keys);
		
		if(arrayOfKeys.size() > 0)
			toReturn = arrayOfKeys.get(rand.nextInt(arrayOfKeys.size()));
		
		return toReturn;
	}

	/**
	 * removes the object property associated with the given GUID.
	 * @param gUID
	 */
	public void removeGuid(String gUID) {
		properties.remove(gUID);
	}

}
