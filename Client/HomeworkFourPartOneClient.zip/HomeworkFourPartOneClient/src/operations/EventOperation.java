package operations;

import objectModel.ObjectMap;
import eventModel.EventManager;

public class EventOperation implements Runnable {
	
	private EventManager eManager;
	private ObjectMap objects;
	
	public EventOperation(ObjectMap map) {
		eManager = EventManager.getManager();
		objects = map;
	}
	
	@Override
	public void run() {
		eManager.manageEvents(objects);
	}

}
