package time;

import java.io.Serializable;
import java.util.PriorityQueue;

import objectModel.ObjectMap;
import eventModel.Event;

/**
 * TimeStep contains the state of one time step in the TimeLine
 * 
 * @author James Woods
 * 
 */
class TimeStep implements Serializable {
	/**
	 * The time that elapsed during this step.
	 */
	public double elapsed_time;
	
	/**
	 * The prioritized queue of events that were handled and triggered during this
	 * time step.
	 */
	public PriorityQueue<Event> events;
	
	/**
	 * The initial state of the object map for this time step.
	 */
	public ObjectMap initial;

	public TimeStep() {
		elapsed_time = 0;
		events = new PriorityQueue<Event>();
		initial = null;
	}
}
