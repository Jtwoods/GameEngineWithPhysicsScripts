package time;

import actionModel.ActionMap;
import operations.EventOperation;
import operations.PhysOperation;
import eventModel.Event;
import eventModel.EventManager;
import eventModel.EventMap;
import factories.ActionFactory;
import factories.EventFactory;
import objectModel.ObjectMap;

public class PlayBackManager {

	private static PlayBackManager manager;
	private int startStep;
	private TimeManager tManager;
	private EventManager eManager;
	private TimeLine playback;
	private ObjectMap map;
	public boolean playing;
	private TimeStep current_step;
	private int play_step;
	private EventMap events;
	private ActionMap actions;
	private boolean hasPlayback;

	private PlayBackManager() {
		startStep = 0;
		playing = false;
		hasPlayback = false;

		tManager = TimeManager.getManager();

		// Build the EventMap.
		EventFactory eFactory = new EventFactory();
		events = eFactory.makeEvents("events.xml");

		// Get the singleton EventManager.
		eManager = EventManager.getManager();
		// Set the event map.
		eManager.setEventMap(events);

		// Build the ActionMap.
		ActionFactory aFactory = new ActionFactory();
		actions = aFactory.makeActions("actions.xml");
	}

	public static PlayBackManager getManager() {
		if (manager == null)
			manager = new PlayBackManager();
		return manager;
	}

	public void setStart() {
		hasPlayback = true;
		startStep = tManager.setStart();
	}

	public void startPlayBack(double tic_size) {
		if (hasPlayback) {
			// Let the system know we are in play-back mode.
			playing = true;
			// Initialize the local step value.
			play_step = 0;
			// Get the Local time line.
			playback = tManager.getTimeLine(startStep, tManager.getStep(),
					tic_size);
			// Get the initial step from the local time line.
			current_step = playback.getStep(play_step++);
			// Get the object map for the local time line start.
			map = playback.getObjectMapStart();
		}
	}

	/**
	 * takeStep performs all physics and event handling for a local time step
	 * and returns the ObjectMap that should be displayed for that local time
	 * line.
	 * 
	 * @return the ObjectMap to be displayed.
	 */
	public ObjectMap takeStep() {

		double current_event_time = (double) 0.0;
		double previous_event_time = (double) 0.0;

		double adjusted_time = current_event_time - previous_event_time;

		// Do stuff with the current step.
		Thread physThread = new Thread(new PhysOperation(actions, map,
				current_step.elapsed_time));
		physThread.start();
		try {
			physThread.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		eManager.purgeQueue();
		eManager.addAllEvents(current_step.events);

		Thread eventThread = new Thread(new EventOperation(map));
		eventThread.start();
		try {
			eventThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// Save the event time from this pass.
		previous_event_time = current_event_time;

		// Set the next step.
		current_step = playback.getStep(play_step++);
		if (current_step == null) {
			playing = false;
			// Can create an event here.
		}

		return map;
	}

	public void setTimeManager(TimeManager tManager) {
		this.tManager = tManager;
	}

	/**
	 * Sets the play back manager to initial state.
	 */
	public void reset() {
		startStep = 0;
		playing = false;
		hasPlayback = false;
		eManager.purgeQueue();

	}

}
