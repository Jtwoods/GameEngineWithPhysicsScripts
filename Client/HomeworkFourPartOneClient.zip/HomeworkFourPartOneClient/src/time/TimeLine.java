package time;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.PriorityQueue;

import objectModel.ObjectMap;
import eventModel.Event;

/**
 * TimeLine keeps a record of the steps in a global or local time line.
 * 
 * @author James Woods
 * 
 */
public class TimeLine implements Serializable {
	protected ArrayList<TimeStep> steps;

	public TimeLine() {
		steps = new ArrayList<TimeStep>();
	}
	
	public void addStep(TimeStep step) {
		steps.add(step);
	}

	public ObjectMap getObjectMapStart() {
		return steps.get(0).initial;
	}

	public TimeLine slice(int start, int finish) {
		TimeLine toReturn = new TimeLine();
		ArrayList<TimeStep> steps_toReturn = new ArrayList<TimeStep>();
		steps_toReturn.addAll((steps.subList((int)start, (int)(finish))));
		toReturn.steps = steps_toReturn;
		return toReturn;
	}

	public TimeStep getStep(int play_step) {
		if(play_step >= steps.size())
			return null;
		return steps.get(play_step);
	}
}
