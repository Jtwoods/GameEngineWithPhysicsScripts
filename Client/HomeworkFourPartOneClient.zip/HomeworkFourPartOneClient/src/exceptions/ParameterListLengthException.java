package exceptions;

public class ParameterListLengthException extends Exception {
	public ParameterListLengthException(String type, String class_name, int length) {
		super("The class " + class_name + " of type " + type + "is of the incorrect length " + length);
	}
}
