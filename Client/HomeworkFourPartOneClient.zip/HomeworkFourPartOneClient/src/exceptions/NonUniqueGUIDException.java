package exceptions;

public class NonUniqueGUIDException extends Exception {
	
	public NonUniqueGUIDException(String GUID) {
		super("The GUID " + GUID + " already exists.");
	}

}
